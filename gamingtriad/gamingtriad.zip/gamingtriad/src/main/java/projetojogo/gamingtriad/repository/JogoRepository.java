package projetojogo.gamingtriad.repository;

import projetojogo.gamingtriad.domain.Jogo;

import java.util.List;

public interface JogoRepository {
    List<Jogo> listAll();
}
