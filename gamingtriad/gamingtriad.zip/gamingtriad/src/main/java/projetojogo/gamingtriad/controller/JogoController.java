package projetojogo.gamingtriad.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import projetojogo.gamingtriad.domain.Jogo;
import projetojogo.gamingtriad.service.JogoService;
import projetojogo.gamingtriad.util.DateUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("jogo")
@Log4j2
@RequiredArgsConstructor
public class JogoController {
    private final DateUtil dateUtil;
    private final JogoService jogoService;

    @GetMapping
    public ResponseEntity<List<Jogo>> list(){
        log.info(DateUtil.formatLocalDateTimeToDatabaseStyle(LocalDateTime.now()));
        return ResponseEntity.ok(jogoService.listAll());
    }

    @GetMapping(path = "/{id}")
    public ResponseEntity<Jogo> findById(@PathVariable long id){
        return ResponseEntity.ok(jogoService.findById(id));
    }

    @PostMapping
    public ResponseEntity<Jogo> save(@RequestBody Jogo jogo){
        return new ResponseEntity<>(jogoService.save(jogo), HttpStatus.CREATED);
    }

    @DeleteMapping(path = "/{id}")
    public ResponseEntity<Void> delete(@PathVariable long id){
        jogoService.delete(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PutMapping
    public ResponseEntity<Void> replace(@RequestBody Jogo jogo){
        jogoService.replace(jogo);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
