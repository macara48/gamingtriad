package projetojogo.gamingtriad.requests;

import lombok.Data;

@Data
public class JogoPutRequestBody {
    private Long id;
    private String name;
}
