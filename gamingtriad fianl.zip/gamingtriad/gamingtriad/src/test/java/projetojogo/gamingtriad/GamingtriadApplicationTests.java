package projetojogo.gamingtriad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GamingtriadApplicationTests {

	@Test
	void contextLoads() {
	}

}
